from tkinter import *
import webbrowser

win = Tk()
win.title("Search Bar")

def search():
    url = entry.get()
    webbrowser.open(url)
    win.destroy()
label1 = Label(win,text="Enter URL Here:")
label1.grid(row=0,column=0)

entry = Entry(win,width=30)
entry.grid(row=0,column=1)

button = Button(win,text="Search", command=search)
button.grid(row=1, column=0, columnspan=2, pady=10)
label3 = Label(win,text="Copyright © 2020 The-301-Partnership"
               ,font=("arial", 10,"bold"))
label3.grid(row=10,column=0,columnspan=2)

__author__ = "The-301-Partnership"
__copyright__ = "Copyright (C)© 2020 The-301-Partnership"
__license__ = "MIT License"
__version__ = "1.0"
win.mainloop()